# SEM_6_Mini_Project

This project is made for demonstration of web scraping libraries like selenium, BeautifulSoup and request.

to run ```main.py``` , need to install a few libraries.

### Pandas:
```pip install pandas```

### BeautifulSoup:
```pip install beautifulsoup4```

### selenium: 
```pip install selenium```

### Install Virtual Environment:
```pip install virtualenv```

Create Python virtual environment:
```virtualenv venv```

### Flask:
```pip install flask```



 
